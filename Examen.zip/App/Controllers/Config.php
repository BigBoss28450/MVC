<?php

    class Config_controller {
        function index() {
            echo 'Hola mundo';
        }
    }
    
?>