    <script src="<?=BASE_URL?>App/Assets/js/home.js"></script>
    </body>
</html>